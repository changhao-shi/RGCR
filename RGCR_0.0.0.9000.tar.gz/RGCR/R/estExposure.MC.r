#' @title Exposure probabilities
#' @description
#' Estimate exposure probabilities with Monte Carlo method.
#'
#' @param W an undirected unweighted adjacent matrix.
#' @param cluster.type the clustering type, can be chosen from '3net', '1hop' and 'naive'.
#' @param rand.type the randomization type. You can choose it from "com" (complete randomization) or "ind" (Bernoulli randomization).
#' @param weight.type the weighting type, can be chosen from 'uniform', 'spectral', 'degree'.
#' @param p an numeric between 0 and 1, the probability of treatment 1.
#' @param K an integer, Monte Carlo times of clustering.
#' @param L an integer, Monte Carlo times of cluster randomization.
#' @param delta an personalized vector with values between 0 and 1, reflecting the assumed proportional exposure mapping. Details are in our work.
#' @param W.squared the 2nd order adjacent matrix of W. To reduce computing costs, not necessary.
#' @param eig.value a numeric, the max eigenvalue of W.squared. To reduce computing costs, not necessary.
#'
#' @return a matrix, estimated exposure probabilities under corresponding assumed exposure mappings.
#' @export
#'
estExposure.MC = function(W,
                          cluster.type=c('3net','1hop','naive'),
                          rand.type=c('com','ind'),
                          weight.type=c('uniform','spectral','degree'),
                          p=0.5, K=5, L=5,
                          delta = seq(0,1,0.05),
                          W.squared=NA,
                          eig.value=NA) {
  t1 = Sys.time()

  n = nrow(W)
  if(is.na(W.squared[1])) {W.squared = getAdjMat.d(W,2)}
  if(is.na(eig.value[1])) {eig.value =  eigen(W.squared)$vectors[,1]}

  ep1h = matrix(0,n,length(delta))
  ep0h = matrix(0,n,length(delta))


  weight = RGCR.weighting(W=W,
                          W.squared=W.squared,
                          type=weight.type,
                          eig.value = eig.value)
  weight.sum = sum(weight)

  for (prior in 1:n) {

    ep1.prior = matrix(0,n,length(delta))
    ep0.prior = matrix(0,n,length(delta))

    for(k in 1:K) {

      cluster = RGCR.clustering(W=W,
                                W.squared=W.squared,
                                weight=weight,
                                prior=prior,
                                type=cluster.type)

      for(l in 1:L) {

        valid = RGCR.randomization.delta(W, cluster, p, rand.type, delta)
        valid.1 = valid$valid.1
        valid.0 = valid$valid.0

        ep1.prior = ep1.prior + valid.1
        ep0.prior = ep0.prior + valid.0

      }
    }

    ep1h = ep1h + ep1.prior * weight[prior]
    ep0h = ep0h + ep0.prior * weight[prior]

  }

  ep1h = ep1h/weight.sum/K/L
  ep0h = ep0h/weight.sum/K/L

  t2 = Sys.time()
  print(t2-t1)

  return(list(ep1h=ep1h, ep0h=ep0h))
}
