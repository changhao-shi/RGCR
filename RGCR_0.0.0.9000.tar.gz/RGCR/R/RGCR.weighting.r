
#' @title Weight for clustering
#' @description Get a weight for clustering algorithm. There are 3 weighting types
#' can be chosen: 'uniform', 'spectral', 'degree'. Details are in the paper.
#'
#' @param W an undirected unweighted adjacent matrix.
#' @param W.squared the 2nd order adjacent matrix of W. To reduce computing costs, not necessary.
#' @param type the weighting type, can be chosen from 'uniform', 'spectral', 'degree'.
#' @param eig.value a numeric, the max eigenvalue of W.squared. To reduce computing costs, not necessary.
#'
#' @return Return the weight under specific weighting types.
#' @references Ugander, J. and Yin, H., 2023. Randomized graph cluster randomization. *Journal of Causal Inference*, 11(1), p.20220014.
#' @export
#'
RGCR.weighting = function(W,
                          W.squared = NA,
                          type=c('uniform','spectral','degree'),
                          eig.value = NA) {
  n = nrow(W)
  if(type=='uniform') {
    weight = rep(1,n)
  } else if(type=='degree') {
    weight = W %*% rep(1,n)
  } else if(type=='spectral') {
    if(is.na(W.squared[1])) {W.squared = getAdjMat.d(W,2)}
    if(is.na(eig.value[1])) {eig.value =  eigen(W.squared)$vectors[,1]}
    weight = abs(eig.value)
  } else {cat('Error in the RGCR.weighting!\n')}

  return(weight)
}
