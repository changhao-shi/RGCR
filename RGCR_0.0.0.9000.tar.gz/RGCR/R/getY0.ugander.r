#' @title Ugander's Y0
#' @description
#' Generate Ugander's potential outcomes Y0.
#'
#' @param filename the file that stores data.
#' @param a a numeric, intercept of Y0.
#' @param b a numeric, related to the homophily.
#' @param sigma a numeric, related to the variance.
#'
#' @return an n-dimensional vector, y0.
#' @references Ugander, J. and Yin, H., 2023. Randomized graph cluster randomization. *Journal of Causal Inference*, 11(1), p.20220014.
#' @export
#'
getY0.ugander = function(filename='',
                         a=1,
                         b=0.5,
                         sigma=0.1) {

  info.response = read.csv(paste0(filename,'-response.txt'), sep='')
  h = info.response$h
  e = info.response$e
  info.node = read.csv(paste0(filename,'-node_meta.txt'), sep='')
  d.bar = mean(info.node$d_1)
  d = info.node$d_1/d.bar
  y0 = (a+b*h+sigma*e)*d
  return(y0)
}
