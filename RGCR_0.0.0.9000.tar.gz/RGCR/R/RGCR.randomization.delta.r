
#' @title Cluster randomization with auxiliary results
#' @description
#' Implement randomization at the level of clusters and
#' return valid nodes under corresponding exposure mappings.
#'
#' @param W an undirected unweighted adjacent matrix.
#' @param cluster an n-dimensional vector with the values of cluster labels.
#' @param p an numeric between 0 and 1, the probability of treatment 1.
#' @param type the randomization type. You can choose it from "com" (complete randomization)
#' or "ind" (Bernoulli randomization).
#' @param delta a personalized vector with values between 0 and 1,
#' which reflects the strength of exposure mapping. Details are in our work.
#'
#' @return
#' \item{\code{treat}}{the treatment assignment of nodes description, which is an n-dimensional vector with values of 0 or 1.}
#' \item{\code{valid.1}}{valid treatment nodes under corresponding exposure mappings.}
#' \item{\code{valid.0}}{valid control nodes under corresponding exposure mappings.}
#'
#' @export
#'
RGCR.randomization.delta = function(W,
                                    cluster,
                                    p=0.5,
                                    type=c('com','ind'),
                                    delta=seq(0,1,0.05)) {
  treat = rep(0,nrow(W))
  if(type=='com') {
    treat = rand.com(W,cluster,p)
  } else if(type=='ind') {
    treat = rand.ind(W,cluster,p)
  } else {
    cat('Error in the RGCR.randomization.delta!\n')
  }
  valid = getValidNode.delta(W,treat,delta)
  valid.1 = valid$valid.1
  valid.0 = valid$valid.0
  return(list(treat=treat,valid.1=valid.1,valid.0=valid.0))
}
