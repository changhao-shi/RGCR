#' @title Valid node
#' @description
#' Get valid node under specific exposure mappings.
#'
#' @param A an undirected unweighted adjacent matrix.
#' @param z an n-dimensional vector with values of 1 or 0.
#' @param delta an personalized vector with values between 0 and 1, reflecting the assumed proportional exposure mapping. Details are in our work.
#'
#' @return
#' \item{\code{valid.1}}{valid treatment nodes under corresponding exposure mappings.}
#' \item{\code{valid.0}}{valid control nodes under corresponding exposure mappings.}
#' @export
#'
getValidNode.delta = function(A, z, delta=seq(0,1,0.05)) {
  n = nrow(A)
  delta.length = length(delta)
  d = A %*% rep(1,n)
  d.tilde = d
  d.tilde[which(d==0)] = -1
  zero.mat = matrix(rep(d==0,delta.length),n,delta.length)

  ratio = matrix(rep( (A %*% z)/d.tilde, delta.length ),n,delta.length)

  valid.1 = (ratio >= matrix(rep(delta,n),n,delta.length, byrow = T)) & (!zero.mat) # weak to strong
  valid.1 = (valid.1|zero.mat) & matrix(rep(z,delta.length),n,delta.length)

  # not good, when delta=1, need to generate corresponding full-neighborhood interference.
  valid.0 = (ratio <= matrix(rep(delta,n),n,delta.length, byrow = T)) & (!zero.mat) # strong to weak
  valid.0 = (valid.0|zero.mat) & (!matrix(rep(z,delta.length),n,delta.length))

  colnames(valid.1) = delta
  colnames(valid.0) = delta

  return(list(valid.1=valid.1,valid.0=valid.0))
}
