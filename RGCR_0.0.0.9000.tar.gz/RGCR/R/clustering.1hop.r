
#' @title 1-hop clustering
#' @description Generate clustering results with 1-hop clustering algorithm.
#'
#' @param W an undirected unweighted adjacent matrix.
#' @param W.squared the 2nd order adjacent matrix of W. It's to reduce computing costs, not necessary.
#' @param weight an n-dimensional vector, the weight for clustering.
#' @param prior an integer indicating which node is 'preferred'. Details are in the paper.
#'
#' @return Return the clustering result, which is an n-dimensional vector with values of cluster labels.
#'
#' @references Ugander, J. and Yin, H., 2023. Randomized graph cluster randomization. *Journal of Causal Inference*, 11(1), p.20220014.
#' @export
#'
#'
clustering.1hop = function(W, W.squared=NA, weight=NA, prior=NA) {
  n = nrow(W)
  cluster = rep(0,n)
  ver.rand = rep(0,n)
  if(is.na(W.squared[1])) {W.squared = getAdjMat.d(W,2)}
  if(is.na(weight[1])) {weight=rep(1,n)}
  x.w = rbeta(n,weight,rep(1,n))
  if(!is.na(prior)) {x.w[prior] = max(x.w)+1}

  for(k in 1:n) {
    b1 = c(k, which(W[k,]==1))
    cluster[k] = max(x.w[b1])
  }

  cluster = as.integer(as.factor(cluster))

  return(cluster)
}
