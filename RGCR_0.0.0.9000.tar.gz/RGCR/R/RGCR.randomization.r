
#' @title Cluster randomization
#' @description
#' Implement randomization at the level of clusters.
#'
#'
#' @param W an undirected unweighted adjacent matrix.
#' @param cluster an n-dimensional vector with the values of cluster labels.
#' @param p an numeric between 0 and 1, the probability of treatment 1.
#' @param type the randomization type. You can choose it from "com" (complete randomization) or "ind" (Bernoulli randomization).
#'
#' @return Return the treatment assignment of nodes, which is an n-dimensional vector with values of 0 or 1.
#' @export
RGCR.randomization = function(W, cluster, p=0.5, type='com') {
  treat = rep(0,nrow(W))
  if(type=='com') {
    treat = rand.com(W,cluster,p)
  } else if(type=='ind') {
    treat = rand.ind(W,cluster,p)
  } else {
    cat('Error in the RGCR.randomization!\n')
  }

  return(treat)
}
