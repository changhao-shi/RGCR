

#' @title Naive clustering
#' @description Generate clustering results with naive clustering algorithm.
#' In this algorithm, every node is a cluster itself.
#'
#' @param W an undirected unweighted adjacent matrix.
#' @param W.squared the 2nd order adjacent matrix of W. It's to reduce computing costs, not necessary.
#' @param weight an n-dimensional vector, the weight for clustering.
#' @param prior an integer indicating which node is 'preferred'. Details are in the paper.
#'
#'
#' @return Return the clustering result, which is an n-dimensional vector with values of cluster labels.
#' @export
#'
clustering.naive = function(W, W.squared=NA, weight=NA, prior=NA) {
  n = nrow(W)
  cluster = seq(1,n,1)
  return(cluster)
}
