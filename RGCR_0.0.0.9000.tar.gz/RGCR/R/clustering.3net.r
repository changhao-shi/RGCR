
#' @title 3-net clustering
#' @description Generate clustering results with 3-net clustering algorithm.
#'
#' @param W an undirected unweighted adjacent matrix.
#' @param W.squared the 2nd order adjacent matrix of W. It's to reduce computing costs, not necessary.
#' @param weight an n-dimensional vector, the weight for clustering.
#' @param prior an integer indicating which node is 'preferred'. Details are in the paper.
#'
#' @return Return the clustering result, which is an n-dimensional vector with values of cluster labels.
#' @references Ugander, J. and Yin, H., 2023. Randomized graph cluster randomization. *Journal of Causal Inference*, 11(1), p.20220014.
#' @export
clustering.3net = function(W, W.squared=NA, weight=NA, prior=NA) {
  n = nrow(W)
  cluster = rep(0,n)
  ver.rand = rep(0,n)
  if(is.na(W.squared[1])) {W.squared = getAdjMat.d(W,2)}
  if(is.na(weight[1])) {weight=rep(1,n)}
  x.w = rbeta(n,weight,rep(1,n))
  if(!is.na(prior)) {x.w[prior] = max(x.w)+1}
  ver.rand = order(x.w, decreasing = T)  # argmax_{index} to argmin_{index} of x.w

  S = rep(0,n)  # seed set
  M = rep(0,n)  # marked set

  cluster.num = 0

  # 没问题，对于零度节点依然适用
  # d = W %*% rep(1,n)
  # node.zero = which(d==0)
  # ver.rand = setdiff(ver.rand,node.zero)

  for(k in ver.rand) {
    if(M[k]==0) {  # if equals to 0, is selected as the seed.
      S[k] = 1
      b2 = c(k, which(W.squared[k,]==1))
      # if a node at the margin of 2 circles with r=2, it belongs to the latter
      # 人家不存在顺序的问题，这个问题是在这一步连带解决的
      M[b2] = 1
      cluster.num = cluster.num + 1
      cluster[b2] = cluster.num
    }
  }

  ## if a node at the margin of a circle with r=1 and one with r=2,
  ## it belongs to the former
  for(s in which(S==1)) {
    b1 = c(s, which(W[s,]==1))
    cluster[b1] = cluster[s]
  }



  cluster = as.integer(cluster)
  return(cluster)
}
