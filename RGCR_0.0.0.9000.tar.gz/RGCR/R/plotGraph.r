
#' @title Clustering graph
#' @description
#' Plot a graph reflecting the clustering results.
#'
#'
#' @param W an undirected unweighted adjacent matrix.
#' @param cluster an n-dimensional vector with the values of cluster labels.
#' @param valid1 valid treatment nodes.
#' @param valid0 valid control nodes
#' @param dist an integer indicating the personalized distance between different clusters.
#'
#' @return The graph of the clustering results.
#' @export
#'
plotGraph = function(W,cluster,valid1,valid0,dist=10) {
  getAdjMatForGraph = function(W, cluster, dist=10) {
    W.net = W
    for(i in 1:nrow(W)) {
      for(j in 1:ncol(W)) {
        if(cluster[i]!=cluster[j] && W[i,j]!=0) {
          W.net[i,j] = dist
        }
      }
    }
    return(W.net)
  }
  color = c(           "#cbd5e8","#f4cae4","#e6f5c9","#fff2ae",
                       "#9fb1c2","#e2a3c7","#c3e8b0","#f3d6a9",
                       "#b5c5d3","#ed7baf","#a5d6a7","#f7b977",
                       "#d1dce8","#f5b0cb",
                       "#c9d9e7","#f6bedb","#d5ebc8","#fff6b2",
                       "#c1d6e2","#f2c8d8","#d8efb7","#fff1a8",
                       "#c6d2dd","#f6bad3","#daeecd","#fef6b1",
                       "#f6c5cc","#f2b2bd","#f8d7d9",
                       "#e8cfe6","#e6bce0","#f2d8f1",
                       "#c5d9ed","#b3cde7","#d5e5f5",
                       "#c9e9c6","#b8e0b4","#d6f2d8",
                       "#fff4b3","#ffe9a4","#fffad4",
                       "#fcd5b5","#facaa6","#fee2c9",
                       "#f2c2d2","#d2e2f2","#e1f1d1","#fcf0c0",
                       "#e8c5d5","#d9e6d9","#e2f5c2","#fff7b1",
                       "#d5c3e3","#e7f2dc","#f7f3c6","#e5d5c5",
                       "#e7cfe1","#f7d9b9","#dae7c6","#c7d5e5",
                       "#e1eed6","#e5c9d9","#f2e1c2","#d5e8f2",
                       "#f0f2d2","#d9c5f7","#e3f1d1","#f7f0c0",
                       "#e5d6c1","#c1e5d6","#d6c1e5","#f7c1d9",
                       "#d9f7c1","#c1d9f7","#f2d9c1","#c1f2d9",
                       "#d9c1f2","#e1f7c1","#c1e1f7","#f7e1c1"
                     )

  W.graph = getAdjMatForGraph(W, cluster, dist=dist)
  color = getColors()
  color.graph = color[cluster %% length(color)]
  color.graph[valid1] = "black"
  color.graph[valid0] = "white"
  graph = graph_from_adjacency_matrix(W.graph, mode="undirected", weighted=T)
  l.graph = layout.kamada.kawai(graph)
  plot(graph, vertex.color = color.graph, vertex.size = 8, layout= l.graph,  vertex.label = "")
}
