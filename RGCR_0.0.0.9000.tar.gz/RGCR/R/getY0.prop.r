#' @title Proportional Y0
#' @description
#' Generate proportional potential outcomes Y0.
#'
#' @param filename the file that stores data.
#'
#' @return an n-dimensional vector, y0.
#' @export
#'
getY0.prop = function(filename='') {
  y0=read.csv(paste0(filename,'-y0.txt'), sep='')$y0
  return(y0)
}
