#' @title Higher order adjacent matrix
#' @description
#' Get the \code{d}th order adjacent matrix of W.
#'
#' @param W the adjacent matrix.
#' @param d an interger, the \code{d}th order.
#'
#' @return the \code{d}th order adjacent matrix of W.
#' @export
#'
getAdjMat.d = function(W,d) {
  W.d = W
  W.k = W
  for(k in 1:(d-1)) {
    W.k = W.k %*% W  # (k+1) steps to reach
    # w.d = W.d + W.k  # an error: W, w is a terrible name!
    W.d = W.d + W.k  # radius \leq (k+1)'s neighbors
  }
  W.d = (W.d > 0)
  diag(W.d) = 0
  return(W.d)
}
