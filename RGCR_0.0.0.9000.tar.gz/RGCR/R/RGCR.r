
#' @title Randomized Graph Cluster Randomization
#' @description
#' Implement randomized graph cluster randomization
#'
#' @param W an undirected unweighted adjacent matrix.
#' @param cluster.type the clustering type, can be chosen from '3net', '1hop' and 'naive'.
#' @param rand.type the randomization type. You can choose it from "com" (complete randomization) or "ind" (Bernoulli randomization).
#' @param weight.type the weighting type, can be chosen from 'uniform', 'spectral', 'degree'.
#' @param p an numeric between 0 and 1, the probability of treatment 1.
#' @param prior an integer indicating which node is 'preferred'. Details are in the paper.
#' @param W.squared the 2nd order adjacent matrix of W. To reduce computing costs, not necessary.
#' @param eig.value a numeric, the max eigenvalue of W.squared. To reduce computing costs, not necessary.
#'
#' @return Return the treatment assignment of nodes, which is an n-dimensional vector with values of 0 or 1.
#' @references Ugander, J. and Yin, H., 2023. Randomized graph cluster randomization. *Journal of Causal Inference*, 11(1), p.20220014.
#' @export
#'
RGCR = function(W,
                cluster.type = c('3net','1hop','naive'),
                rand.type=c('com','ind'),
                weight.type=c('uniform','spectral','discard'),
                p=0.5,
                prior=NA,
                W.squared=NA,
                eig.value=NA) {

  n = nrow(W)
  if(is.na(W.squared[1])) {W.squared = getAdjMat.d(W,2)}
  if(is.na(eig.value[1])) {eig.value =  eigen(W.squared)$vectors[,1]}

  weight = RGCR.weighting(W=W,
                          W.squared=W.squared,
                          type=weight.type,
                          eig.value = eig.value)
  cluster = RGCR.clustering(W=W,
                            W.squared=W.squared,
                            weight=weight,
                            prior=prior,
                            type=cluster.type)
  treat = RGCR.randomization(W=W,
                             cluster=cluster,
                             p=p,
                             type=rand.type)
  res = data.frame(node=1:n, cluster=cluster, treat=treat)

  return(res)
}
