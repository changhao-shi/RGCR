#' @title Proportional Y
#' @description
#' Generate proportional potential outcomes Y.
#'
#' @param A an undirected unweighted adjacent matrix.
#' @param z an n-dimensional vector with values of 1 or 0.
#' @param y0 an n-dimensional vector, baseline potential outcomes y0.
#' @param prop a numeric between 0 and 1, reflecting the proportional exposure mapping. Details are in our work.
#' @param beta a numeric, the direct effect.
#' @param gamma a numeric, the indirect (spillover) effect.
#'
#' @return an n-dimensional vector, y.
#' @export
#'
getY.prop = function(A,
                     z,
                     y0,
                     prop = c(0,1),
                     beta = 1,
                     gamma = 1) {

  y = y0 + beta * z
  if(prop!=0) {

    n = nrow(A)
    d = A %*% rep(1,n)
    d.nonzero = which(d!=0)
    delta = as.vector( (A %*% z) / d )

    y[d.nonzero] = y[d.nonzero] + gamma*(pmin(delta[d.nonzero]/prop,1) * z[d.nonzero] + pmax((delta[d.nonzero]+prop-1)/prop,0) * (1-z[d.nonzero]))^2
  }
  return(y)
}
