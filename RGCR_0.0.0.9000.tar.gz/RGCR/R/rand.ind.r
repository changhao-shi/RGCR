#' @title Bernoulli randomization
#' @description
#' Implement Bernoulli randomization at the level of clusters.
#'
#' @param W an undirected unweighted adjacent matrix.
#' @param cluster an n-dimensional vector with the values of cluster labels.
#' @param p an numeric between 0 and 1, the probability of treatment 1.
#'
#' @return Return the treatment assignment of nodes, which is an n-dimensional vector with values of 0 or 1.
#' @export
#'
rand.ind = function(W, cluster, p=0.5) {
  cluster.name = unique(cluster)
  n = length(cluster.name)
  treat = cluster.name[as.logical(rbinom(n,1,p))]
  treat = as.integer(cluster %in% treat)
  return(treat)
}
