
#' @title Randomized graph clustering
#' @description Generate randomized graph clustering results.
#'
#' @param W an undirected unweighted adjacent matrix.
#' @param W.squared the 2nd order adjacent matrix of W. It's to reduce computing costs, not necessary.
#' @param weight an n-dimensional vector, the weight for clustering.
#' @param prior an integer indicating which node is 'preferred'. Details are in the paper.
#' @param type the clustering type, can be chosen from '3net', '1hop' and 'naive'.
#'
#' @return Return the clustering result under specific types, which is an n-dimensional vector with values of cluster labels.
#' @references Ugander, J. and Yin, H., 2023. Randomized graph cluster randomization. *Journal of Causal Inference*, 11(1), p.20220014.
#' @export
#'
RGCR.clustering = function(W,
                           W.squared=NA,
                           weight=NA,
                           prior=NA,
                           type=c('3net','1hop','naive')) {
  cluster = rep(0,nrow(W))
  if(type=='3net') {
    cluster=clustering.3net(W,W.squared,weight,prior)
  } else if (type=='1hop') {
    cluster=clustering.1hop(W,W.squared,weight,prior)
  } else if (type=='naive') {
    cluster=clustering.naive(W,W.squared,weight,prior)
  } else {
    cat('Error in the RGCR.clustering!\n')
  }
  return(cluster)
}
