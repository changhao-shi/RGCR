#' @title Ugander's Y
#' @description
#' Generate Ugander's potential outcomes Y.
#'
#' @param A an undirected unweighted adjacent matrix.
#' @param z an n-dimensional vector with values of 1 or 0.
#' @param y0 an n-dimensional vector, baseline potential outcomes y0.
#' @param beta a numeric, the direct effect.
#' @param gamma a numeric, the indirect (spillover) effect.
#'
#' @return an n-dimensional vector, y.
#' @export
#'
getY.Ugander = function(A,
                        z,
                        y0,
                        beta=1,
                        gamma=1) {

  n = nrow(A)
  d = A %*% rep(1,n)
  d.nonzero = which(d!=0)
  d.zero = which(d==0)
  delta = as.vector( (A %*% z) / d )
  y = y0
  y[d.nonzero] = y0[d.nonzero]*(1+beta*z[d.nonzero]+gamma*delta[d.nonzero]^2)
  y[d.zero] = y0[d.zero]*(1+beta*z[d.zero])

  return(y)

}
