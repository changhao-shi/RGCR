#' @title Adjacent matrix
#' @description
#' Get adjacent matrix from .csv files.
#'
#' @param filename the file that stores data.
#'
#' @return an adjacent matrix.
#' @export
#'
getAdjMat = function(filename='') {
  ## delete the 1st row in the raw data, BY HAND
  G = read.csv(paste0(filename,'.txt'), sep='')
  if(min(G)==0) {G = G +1}  # 1st node is 1, not 0
  n = length(unique(c(G[,1],G[,2])))
  W = matrix(0, nrow=n, ncol=n)
  for(k in 1:nrow(G)) {
    W[G[k,1],G[k,2]]=1
  }
  W = W + t(W)
  # diagonal elements are 0
  colnames(W) = 1:n
  rownames(W) = 1:n
  return(W)
}
